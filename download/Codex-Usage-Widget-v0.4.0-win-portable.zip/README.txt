Codex Usage Widget v0.4.0

双击 GPTUsageWidget.exe，或使用桌面的“GPT Usage Widget”快捷方式启动。

- 每 5 秒自动刷新今日 Token 与周额度。
- 窗口可分别调整宽和高，缩小时会依次隐藏次要模块，最小矩形只显示今日 Token。
- 宽、高均达到矩形下限后继续缩小，才会切换为圆形额度球。
- 圆球可等比例缩放；鼠标悬停时显示额度重置日期。
- 双击窗口可在圆球和标准面板之间快速切换。
- 顶部 CN/EN 可切换中英文，主题按钮可循环切换五套配色。
- 拖动窗口空白区域可以移动。
- PIN 切换置顶，X 关闭。
- 圆球模式下右键可刷新、切换尺寸、切换置顶或退出。
- 只读取本机 Codex 会话文件，不需要 API Key，也不会联网。

如需直接以圆球启动，可运行：GPTUsageWidget.exe --compact

完整源码、构建脚本和 GitHub Actions 配置请查看本目录的 README.md。
