Codex Usage Widget v0.3.0

双击 GPTUsageWidget.exe，或使用桌面的“GPT Usage Widget”快捷方式启动。

- 每 5 秒自动刷新今日 Token 与周额度。
- 最小尺寸为圆形额度球，只显示周额度剩余百分比；放大后自动切换为完整面板。
- 双击窗口可在圆球和标准面板之间快速切换，窗口最大尺寸为 480×360。
- 拖动窗口空白区域可以移动。
- PIN 切换置顶，X 关闭。
- 圆球模式下右键可刷新、切换尺寸、切换置顶或退出。
- 只读取本机 Codex 会话文件，不需要 API Key，也不会联网。

如需直接以圆球启动，可运行：GPTUsageWidget.exe --compact

完整源码、构建脚本和 GitHub Actions 配置请查看本目录的 README.md。
