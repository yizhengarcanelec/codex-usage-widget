GPT Usage Widget v0.2.0

1. Double-click GPTUsageWidget.exe.
2. Drag any edge or corner to resize continuously.
3. Drag the empty window area to move it.
4. PIN toggles always-on-top; X closes the widget.

The app reads local Codex session files only. It does not need an API key or network access.
Windows 10/11 is recommended.
